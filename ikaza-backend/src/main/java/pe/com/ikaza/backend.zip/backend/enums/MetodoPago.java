package pe.com.ikaza.backend.enums;

public enum MetodoPago {
    MERCADO_PAGO,
    CULQI,
    TRANSFERENCIA_BANCARIA,
    EFECTIVO_CONTRAENTREGA
}
