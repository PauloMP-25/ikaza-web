package pe.com.ikaza.backend.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/**
 * Utilidad para generar y validar tokens JWT (Actualizado para JJWT moderno)
 * Reemplaza la funcionalidad de Firebase Auth
 */
@Component
public class JwtUtils {

    private static final Logger logger = LoggerFactory.getLogger(JwtUtils.class);

    // Se recomienda usar una clave de al menos 256 bits (32 caracteres en Base64)
    @Value("${jwt.secret:miSecretoSuperSeguroParaProduccionDebeSerMuyLargoYComplejo2024!}")
    private String jwtSecret;

    @Value("${jwt.expiration:86400000}") // 24 horas en milisegundos
    private long jwtExpiration;

    @Value("${jwt.refresh-expiration:604800000}") // 7 días en milisegundos
    private long refreshExpiration;

    /**
     * Generar token JWT desde Authentication
     */
    public String generateJwtToken(Authentication authentication) {
        UserDetails userPrincipal = (UserDetails) authentication.getPrincipal();
        return generateTokenFromUsername(userPrincipal.getUsername());
    }

    /**
     * Generar token JWT desde email (Método actualizado: usa signWith(Key) para
     * evitar deprecación)
     */
    public String generateTokenFromUsername(String email) {
        return Jwts.builder()
                .setSubject(email)
                .setIssuedAt(new Date())
                // La duración del Access Token
                .setExpiration(new Date(System.currentTimeMillis() + jwtExpiration))
                // Actualizado: usamos signWith(SecretKey) para inferir el algoritmo (HS512)
                .signWith(getSigningKey())
                .compact();
    }

    /**
     * Generar Refresh Token (duración mayor) (Método actualizado: usa signWith(Key)
     * para evitar deprecación)
     */
    public String generateRefreshToken(String email) {
        return Jwts.builder()
                .setSubject(email)
                .setIssuedAt(new Date())
                // La duración del Refresh Token
                .setExpiration(new Date(System.currentTimeMillis() + refreshExpiration))
                // Actualizado: usamos signWith(SecretKey) para inferir el algoritmo (HS512)
                .signWith(getSigningKey())
                .compact();
    }

    /**
     * Obtener email del token JWT (Método actualizado: usa Jwts.parser() y requiere
     * setSigningKey)
     */
    public String getUserEmailFromJwtToken(String token) {
        return Jwts.parser() // FIX: Reemplaza parserBuilder() por parser()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

    /**
     * Validar token JWT (Método actualizado: usa Jwts.parser())
     */
    public boolean validateJwtToken(String authToken) {
        try {
            Jwts.parser() // FIX: Reemplaza parserBuilder() por parser()
                    .setSigningKey(getSigningKey())
                    .build()
                    .parseClaimsJws(authToken);
            return true;
        } catch (MalformedJwtException e) {
            logger.error("Token JWT malformado: {}", e.getMessage());
        } catch (ExpiredJwtException e) {
            logger.error("Token JWT expirado: {}", e.getMessage());
        } catch (UnsupportedJwtException e) {
            logger.error("Token JWT no soportado: {}", e.getMessage());
        } catch (IllegalArgumentException e) {
            logger.error("JWT claims vacío: {}", e.getMessage());
        } catch (Exception e) {
            // Generalmente, se captura SignatureException aquí si la firma no es válida
            logger.error("Error al validar token JWT (posiblemente firma inválida): {}", e.getMessage());
        }
        return false;
    }

    /**
     * Verificar si el token está expirado (Método actualizado: usa Jwts.parser())
     */
    public boolean isTokenExpired(String token) {
        try {
            Claims claims = Jwts.parser() // FIX: Reemplaza parserBuilder() por parser()
                    .setSigningKey(getSigningKey())
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
            return claims.getExpiration().before(new Date());
        } catch (ExpiredJwtException e) {
            return true;
        } catch (Exception e) {
            // Si hay cualquier otro error (p. ej. firma inválida), asumimos
            // expirado/inválido
            return true;
        }
    }

    /**
     * Obtener clave de firma segura
     */
    private SecretKey getSigningKey() {
        // Asegura que la clave secreta se maneje como bytes UTF-8 para la generación
        // del SecretKey
        byte[] keyBytes = jwtSecret.getBytes(StandardCharsets.UTF_8);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    /**
     * Obtener tiempo de expiración en milisegundos
     */
    public long getExpirationTime() {
        return jwtExpiration;
    }
}