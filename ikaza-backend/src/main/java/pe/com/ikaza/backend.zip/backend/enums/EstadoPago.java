package pe.com.ikaza.backend.enums;

public enum EstadoPago {
    PENDIENTE,
    PROCESANDO,
    APROBADO,
    RECHAZADO,
    REEMBOLSADO
}
